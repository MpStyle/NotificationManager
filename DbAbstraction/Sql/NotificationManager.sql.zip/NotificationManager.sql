-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 02, 2015 at 11:43 PM
-- Server version: 5.5.43-0ubuntu0.14.04.1-log
-- PHP Version: 5.5.9-1ubuntu4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `NotificationManager`
--
CREATE DATABASE IF NOT EXISTS `NotificationManager` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `NotificationManager`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `applicationInsert`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `applicationInsert`(
	IN `@name` VARCHAR(150)
    , IN `@googleKey` VARCHAR(1024)
    , IN `@windowsPhoneKey` VARCHAR(1024)
)
BEGIN

	INSERT INTO Apps(`name`, googleKey, windowsPhoneKey)
	VALUES (`@name`, `@googleKey`, `@windowsPhoneKey`);
    
END$$

--
-- Functions
--
DROP FUNCTION IF EXISTS `getConfigurationValue`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `getConfigurationValue`(`@Key` VARCHAR(100)) RETURNS varchar(500) CHARSET latin1
BEGIN

DECLARE `@Value` VARCHAR(500);

SELECT `Value` INTO `@Value`
FROM Configurations
WHERE `Key` = `@Key`; 

RETURN `@Value`;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `Apps`
--
-- Creation: Jun 02, 2015 at 01:12 PM
--

DROP TABLE IF EXISTS `Apps`;
CREATE TABLE IF NOT EXISTS `Apps` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(150) NOT NULL,
  `GoogleKey` varchar(1024) DEFAULT NULL,
  `WindowsPhoneKey` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Name_UNIQUE` (`Name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Configurations`
--
-- Creation: Jun 02, 2015 at 09:58 AM
--

DROP TABLE IF EXISTS `Configurations`;
CREATE TABLE IF NOT EXISTS `Configurations` (
  `Key` varchar(450) NOT NULL,
  `Value` varchar(450) DEFAULT NULL,
  PRIMARY KEY (`Key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
