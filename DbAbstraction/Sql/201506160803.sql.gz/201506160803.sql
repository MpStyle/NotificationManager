-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 16, 2015 at 08:03 AM
-- Server version: 5.5.43-0ubuntu0.14.04.1-log
-- PHP Version: 5.5.9-1ubuntu4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `NotificationManager`
--

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `applicationDelete`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `applicationDelete`(IN `@id` INT)
BEGIN

DELETE FROM Applications WHERE Id=`@id`;

END$$

DROP PROCEDURE IF EXISTS `applicationGet`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `applicationGet`(IN `@id` INT
	, IN `@name` VARCHAR(150)
    , IN `@perPage` INT
    , IN `@page` INT)
BEGIN

SET @position := 0;

SELECT Id, `Name`, GoogleKey, WindowsPhoneKey, ClientId
FROM
(
	SELECT (@position := @position + 1) AS Position, Id, `Name`, GoogleKey, WindowsPhoneKey, ClientId
	FROM Applications
	WHERE (`@id` IS NULL OR `@id`=id)
		AND ( `@name` IS NULL OR `name` LIKE CONCAT('%',`@name`,'%') )
) AS PositionResult
WHERE Position>`@page`*`@perPage` AND Position<`@page`*`@perPage`+`@perPage`;

END$$

DROP PROCEDURE IF EXISTS `applicationGetCount`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `applicationGetCount`(IN `@id` INT
	, IN `@name` VARCHAR(150))
BEGIN

SELECT COUNT(Id) AS `AppCount`
FROM Applications
WHERE (`@id` IS NULL OR `@id`=id)
	AND ( `@name` IS NULL OR `name` LIKE CONCAT('%',`@name`,'%') );

END$$

DROP PROCEDURE IF EXISTS `applicationInsert`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `applicationInsert`(IN `@name` VARCHAR(150)
    , IN `@googleKey` VARCHAR(1024)
    , IN `@windowsPhoneKey` VARCHAR(1024)
	, IN `@clientId` VARCHAR(1024))
BEGIN

	INSERT INTO Applications(`Name`, GoogleKey, WindowsPhoneKey, ClientId, CreationDate, UpdateDate)
	VALUES (`@name`, `@googleKey`, `@windowsPhoneKey`, `@clientId`, NOW(), NOW());
    
END$$

DROP PROCEDURE IF EXISTS `applicationLinkDelete`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `applicationLinkDelete`(`@ApplicationId` INT)
BEGIN

DELETE FROM ApplicationLinks
WHERE ApplicationId=`@ApplicationId`;

END$$

DROP PROCEDURE IF EXISTS `applicationLinkGet`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `applicationLinkGet`(IN `@Name` VARCHAR(100), IN `@ApplicationId` INT)
BEGIN

SELECT Id, `Name`, ApplicationId, Applications.Name AS ApplicationName
FROM ApplicationLinks
	INNER JOIN Application ON Application.Id=ApplicationLinks.ApplicationId
WHERE (`@Name` IS NULL OR `@Name`=`Name`)
	AND (ApplicationId=`@ApplicationId` OR `@ApplicationId` IS NULL);

END$$

DROP PROCEDURE IF EXISTS `applicationLinkInsert`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `applicationLinkInsert`(`@Name` VARCHAR(100)
    , `@ApplicationId` INT)
BEGIN

INSERT INTO ApplicationLinks(`Name`, ApplicationId)
VALUES(`@Name`, `@ApplicationId`);

END$$

DROP PROCEDURE IF EXISTS `applicationUpdate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `applicationUpdate`(IN `@id` INT
	, IN `@name` VARCHAR(150)
    , IN `@googleKey` VARCHAR(1024)
    , IN `@windowsPhoneKey` VARCHAR(1024))
BEGIN

	UPDATE Applications
	SET 
		`name`=`@name`
		, googleKey=`@googleKey`
		, windowsPhoneKey=`@windowsPhoneKey`
        , UpdateDate = NOW()
	WHERE id=`@id`;

END$$

DROP PROCEDURE IF EXISTS `deviceDelete`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `deviceDelete`(IN `@id` INT)
BEGIN

DELETE FROM Devices WHERE Id=`@id`;

END$$

DROP PROCEDURE IF EXISTS `deviceGet`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `deviceGet`(IN `@id` INT
	, IN `@enabled` INT
	, IN `@applicationId` INT
    , IN `@typeId` INT, IN `@freeSearch` VARCHAR(50)
	, IN `@perPage` INT
	, IN `@page` INT
)
BEGIN

SET @position := 0;

SELECT Id
	, MobileId
	, `Type`
	, ApplicationVersion
	, ApplicationId
	, ApplicationName
	, Brand
	, Model
	, OSVersion
	, Enabled
FROM
(
	SELECT 
		(@position := @position + 1) AS Position
		, Devices.Id
		, MobileId
		, `DeviceTypes`.`Name` AS `Type`
		, ApplicationVersion
		, Applications.Id AS ApplicationId
		, Applications.`Name` AS ApplicationName
		, Brand
		, Model
		, OSVersion
		, Enabled
	FROM Devices
		LEFT JOIN Devices_Applications ON Devices.Id=DeviceId
		LEFT JOIN Applications ON Applications.Id=Devices_Applications.ApplicationId
		LEFT JOIN DeviceTypes ON DeviceTypes.Id=Devices.TypeId
	WHERE (`@id` IS NULL OR `@id`=Devices.id)
		AND ( `@typeId` IS NULL OR `TypeId`=`@typeId` )
        AND 
        ( 
			`@freeSearch` IS NULL 
				OR MobileId LIKE CONCAT('%',`@freeSearch`,'%') 
                OR Brand LIKE CONCAT('%',`@freeSearch`,'%') 
                OR Model LIKE CONCAT('%',`@freeSearch`,'%') 
                OR Applications.Name LIKE CONCAT('%',`@freeSearch`,'%') 
                OR ApplicationVersion LIKE CONCAT('%',`@freeSearch`,'%') 
		)
		AND ( `@enabled` IS NULL OR `enabled` = `@enabled` )
		AND ( `@applicationId` IS NULL OR Applications.Id = `@applicationId` )
) AS PositionResult
WHERE Position>`@page`*`@perPage` AND Position<`@page`*`@perPage`+`@perPage`;

END$$

DROP PROCEDURE IF EXISTS `deviceGetCount`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `deviceGetCount`(IN `@id` INT, IN `@enabled` INT, IN `@applicationId` INT, IN `@typeId` INT, IN `@freeSearch` VARCHAR(50)
)
BEGIN

SELECT 
	COUNT( Devices.Id ) AS `DeviceCount`
FROM Devices
	LEFT JOIN Devices_Applications ON Devices.Id=DeviceId
	LEFT JOIN Applications ON Applications.Id=Devices_Applications.ApplicationId
WHERE (`@id` IS NULL OR `@id`=Devices.id)
	AND ( `@typeId` IS NULL OR `TypeId`=`@typeId` )
	AND 
	( 
		`@freeSearch` IS NULL 
			OR MobileId LIKE CONCAT('%',`@freeSearch`,'%') 
			OR Brand LIKE CONCAT('%',`@freeSearch`,'%') 
			OR Model LIKE CONCAT('%',`@freeSearch`,'%') 
	)
	AND ( `@enabled` IS NULL OR `enabled` = `@enabled` )
	AND ( `@applicationId` IS NULL OR Applications.Id = `@applicationId` );

END$$

DROP PROCEDURE IF EXISTS `deviceGetPageCount`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `deviceGetPageCount`(IN `@id` INT
	, IN `@enabled` INT
	, IN `@applicationId` INT
    , IN `@typeId` INT, IN `@freeSearch` VARCHAR(50)
	, IN `@perPage` INT
)
BEGIN

SELECT 
	CEILING(COUNT(Devices.Id)/`@perPage`) AS PageCount
FROM Devices
	LEFT JOIN Devices_Applications ON Devices.Id=DeviceId
	LEFT JOIN Applications ON Applications.Id=Devices_Applications.ApplicationId
WHERE (`@id` IS NULL OR `@id`=Devices.id)
	AND ( `@typeId` IS NULL OR `TypeId`=`@typeId` )
	AND 
	( 
		`@freeSearch` IS NULL 
			OR MobileId LIKE CONCAT('%',`@freeSearch`,'%') 
			OR Brand LIKE CONCAT('%',`@freeSearch`,'%') 
			OR Model LIKE CONCAT('%',`@freeSearch`,'%') 
	)
	AND ( `@enabled` IS NULL OR `enabled` = `@enabled` )
	AND ( `@applicationId` IS NULL OR Applications.Id = `@applicationId` );

END$$

DROP PROCEDURE IF EXISTS `deviceInsert`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `deviceInsert`(
	`@id` INT
    , `@mobileId` VARCHAR(512)
    , `@type` VARCHAR(10)
    , `@oSVersion` VARCHAR(100)
    , `@applicationVersion` TEXT
    , `@brand` VARCHAR(100)
    , `@model` VARCHAR(100)
    , `@enabled` INT
    , `@localization`  VARCHAR(10)
)
BEGIN

INSERT INTO Devices(Id, MobileId, `Type`, Localization, ApplicationVersion, Brand, Model, OSVersion, Enabled, CreationDate, UpdateDate)
VALUES (`@id`, `@mobileId`, `@type`, `@localization`, `@applicationVersion`, `@brand`, `@model`, `@oSVersion`, `@enabled`, NOW(), NOW());

INSERT INTO Localizations (`Name`)
VALUES (`@localization`);

END$$

DROP PROCEDURE IF EXISTS `deviceTypeGet`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `deviceTypeGet`()
BEGIN

SELECT `Name`
FROM DeviceTypes
ORDER BY Id;

END$$

DROP PROCEDURE IF EXISTS `deviceUpdate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `deviceUpdate`(
	IN `@id` INT
	, IN `@enabled` INT
)
BEGIN

	UPDATE Devices
	SET `enabled`=`@enabled`, UpdateDate=NOW()
	WHERE id=`@id`;

END$$

DROP PROCEDURE IF EXISTS `localizationGet`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `localizationGet`(
	`@id` INT
)
BEGIN

SELECT Id, `Name`
FROM Localizations
WHERE Id=`@id` OR `@id` IS NULL;

END$$

DROP PROCEDURE IF EXISTS `notificationGet`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `notificationGet`(IN `@id` INT
	, IN `@applicationId` INT
    , IN `@statusId` INT, IN `@perPage` INT
	, IN `@page` INT
)
BEGIN

SET @position := 0;

SELECT 
	Id
	, Title
	, ShortMessage
	, Message
	, `Status`
	, ApplicationId
	, ApplicationName
	, IconId
    , DeviceType
	, CreationDate
	, UpdateDate
    , LinkType
    , Link
	, StartDateValidation
	, EndDateValidation
FROM
(
	SELECT 
		(@position := @position + 1) AS Position
		, Notifications.Id
		, Title
        , ShortMessage
        , Message
		, `Status`
		, Apps.Id AS ApplicationId
		, Apps.Name AS ApplicationName
		, IconId
        , DeviceType
        , Notifications.CreationDate
        , Notifications.UpdateDate
		, LinkType
		, Link
        , StartDateValidation
        , EndDateValidation
	FROM Notifications
		INNER JOIN Applications ON Applications.Id=Notifications.ApplicationId
	WHERE ( `@id` IS NULL OR Notifications.Id=`@id` )
		AND ( `@applicationId` IS NULL OR Applications.Id=`@applicationId` )
		AND  ( `@statusId` IS NULL OR Notifications.`StatusId`=`@status` )
) AS PositionResult
WHERE Position>`@page`*`@perPage` AND Position<`@page`*`@perPage`+`@perPage`
ORDER BY UpdateDate DESC;

END$$

DROP PROCEDURE IF EXISTS `notificationGetCount`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `notificationGetCount`(IN `@id` INT
	, IN `@applicationId` INT
	, IN `@statusId` INT
)
BEGIN

SELECT 
	COUNT(Devices.Id) AS NotificationCount
FROM Notifications
	INNER JOIN Applications ON Apps.Id=Notifications.ApplicationId
WHERE ( `@id` IS NULL OR Notifications.Id=`@id` )
	AND ( `@applicationId` IS NULL OR Applications.Id=`@applicationId` )
	AND  ( `@statusId` IS NULL OR Notifications.`StatusId`=`@status` );

END$$

DROP PROCEDURE IF EXISTS `notificationGetPageCount`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `notificationGetPageCount`(IN `@id` INT
	, IN `@applicationId` INT
	, IN `@statusId` INT
	, IN `@perPage` INT
)
BEGIN

SELECT 
	CEILING(COUNT(Notifications.Id)/`@perPage`) AS PageCount
FROM Notifications
	INNER JOIN Applications ON Applications.Id=Notifications.ApplicationId
WHERE ( `@id` IS NULL OR Notifications.Id=`@id` )
	AND ( `@applicationId` IS NULL OR Applications.Id=`@applicationId` )
	AND  ( `@statusId` IS NULL OR Notifications.`StatusId`=`@statusId` );

END$$

DROP PROCEDURE IF EXISTS `notificationInsert`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `notificationInsert`(IN `@Title` VARCHAR(100)
    , IN `@ShortMessage` VARCHAR(200)
	, IN `@Message` TEXT
	, IN `@Status` VARCHAR(20)
	, IN `@DeviceType` VARCHAR(45)
	, IN `@StartDate` DATETIME
	, IN `@EndDate` DATETIME
    , IN `@ApplicationId` INT
    , IN `@LinkType` VARCHAR(20)
    , IN `@Link` TEXT
    , IN `@IconId` INT
)
BEGIN

INSERT INTO Notifications(
	`Title`
    , `ShortMessage`
	, `Message`
	, `StatusId`
	, `DeviceType`
	, `StartDateValidation`
	, `EndDateValidation`
    , ApplicationId
    , LinkType
    , Link
    , CreationDate
    , UpdateDate
)
VALUES (
	`@Title`
    , `@ShortMessage`
	, `@Message`
	, `@Status`
	, `@DeviceType`
	, `@StartDate`
	, `@EndDate`
    , `@ApplicationId`
    , `@LinkType`
    , `@Link`
    , NOW()
    , NOW()
);

END$$

DROP PROCEDURE IF EXISTS `notificationUpdate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `notificationUpdate`(
	`@Id` INT
	, `@Title` VARCHAR(100)
    , `@ShortMessage` VARCHAR(200)
	, `@Message` TEXT
	, `@Status` VARCHAR(20)
	, `@DeviceType` VARCHAR(45)
	, `@StartDate` DATETIME
	, `@EndDate` DATETIME
    , `@ApplicationId` INT
    , `@LinkType` VARCHAR(20)
    , `@Link` TEXT
    , `@IconId` INT
)
BEGIN

UPDATE Notifications
SET 
	`Title` = `@Title`
    , `ShortMessage` = `@ShortMessage`
	, `Message` = `@Message`
	, `Status` = `@Status`
	, `DeviceType` = `@DeviceType`
	, `StartDateValidation` = `@StartDate`
	, `EndDateValidation` = `@EndDate`
    , ApplicationId = `@ApplicationId`
    , LinkType = `@LinkType`
    , Link = `@Link`
    , UpdateDate = NOW()
WHERE Id=`@Id`;

END$$

--
-- Functions
--
DROP FUNCTION IF EXISTS `getConfigurationValue`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `getConfigurationValue`(`@Key` VARCHAR(100)) RETURNS varchar(500) CHARSET latin1
    DETERMINISTIC
BEGIN

DECLARE `@Value` VARCHAR(500);

SELECT `Value` INTO `@Value`
FROM Configurations
WHERE `Key` = `@Key`; 

RETURN `@Value`;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ApplicationInternalLinks`
--

DROP TABLE IF EXISTS `ApplicationInternalLinks`;
CREATE TABLE IF NOT EXISTS `ApplicationInternalLinks` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `ApplicationId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_ApplicationId_idx` (`ApplicationId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Applications`
--

DROP TABLE IF EXISTS `Applications`;
CREATE TABLE IF NOT EXISTS `Applications` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(150) NOT NULL,
  `GoogleKey` varchar(1024) DEFAULT NULL,
  `WindowsPhoneKey` varchar(1024) DEFAULT NULL,
  `ClientId` varchar(1024) NOT NULL,
  `CreationDate` datetime NOT NULL,
  `UpdateDate` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Name_UNIQUE` (`Name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `Configurations`
--

DROP TABLE IF EXISTS `Configurations`;
CREATE TABLE IF NOT EXISTS `Configurations` (
  `Key` varchar(450) NOT NULL,
  `Value` varchar(450) DEFAULT NULL,
  PRIMARY KEY (`Key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `DeliveryStatus`
--

DROP TABLE IF EXISTS `DeliveryStatus`;
CREATE TABLE IF NOT EXISTS `DeliveryStatus` (
  `Id` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Devices`
--

DROP TABLE IF EXISTS `Devices`;
CREATE TABLE IF NOT EXISTS `Devices` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `MobileId` varchar(512) NOT NULL,
  `TypeId` varchar(45) NOT NULL,
  `LocalizationId` int(11) NOT NULL,
  `ApplicationVersion` text,
  `Brand` varchar(100) DEFAULT NULL,
  `Model` varchar(100) DEFAULT NULL,
  `OSVersion` varchar(100) DEFAULT NULL,
  `Enabled` int(11) NOT NULL,
  `CreationDate` datetime NOT NULL,
  `UpdateDate` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `MobileId` (`MobileId`),
  KEY `fk_DevicesTypeId_idx` (`TypeId`),
  KEY `fk_DevicesLocalizationId_idx` (`LocalizationId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=83 ;

-- --------------------------------------------------------

--
-- Table structure for table `Devices_Applications`
--

DROP TABLE IF EXISTS `Devices_Applications`;
CREATE TABLE IF NOT EXISTS `Devices_Applications` (
  `DeviceId` int(11) NOT NULL,
  `ApplicationId` int(11) NOT NULL,
  `CreationDate` datetime NOT NULL,
  `UpdateDate` datetime NOT NULL,
  PRIMARY KEY (`DeviceId`,`ApplicationId`),
  KEY `fk_Devices_Application_ApplicationId` (`ApplicationId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Devices_Notifications`
--

DROP TABLE IF EXISTS `Devices_Notifications`;
CREATE TABLE IF NOT EXISTS `Devices_Notifications` (
  `DeviceId` int(11) NOT NULL,
  `NotificationId` int(11) NOT NULL,
  `DeliveryStatus` varchar(44) NOT NULL,
  PRIMARY KEY (`DeviceId`,`NotificationId`),
  KEY `fk_Devices_Notifications_NotificationId` (`NotificationId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Devices_Users`
--

DROP TABLE IF EXISTS `Devices_Users`;
CREATE TABLE IF NOT EXISTS `Devices_Users` (
  `DeviceId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `Enabled` int(11) NOT NULL,
  `CreationDate` varchar(14) NOT NULL,
  `UpdateDate` varchar(14) NOT NULL,
  PRIMARY KEY (`DeviceId`,`UserId`),
  KEY `fk_Devices_Users_UserId` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `DeviceTypes`
--

DROP TABLE IF EXISTS `DeviceTypes`;
CREATE TABLE IF NOT EXISTS `DeviceTypes` (
  `Id` varchar(45) NOT NULL,
  `Name` varchar(45) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Icons`
--

DROP TABLE IF EXISTS `Icons`;
CREATE TABLE IF NOT EXISTS `Icons` (
  `Id` int(11) NOT NULL,
  `Name` varchar(45) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Localizations`
--

DROP TABLE IF EXISTS `Localizations`;
CREATE TABLE IF NOT EXISTS `Localizations` (
  `Id` int(11) NOT NULL,
  `Name` varchar(10) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Notifications`
--

DROP TABLE IF EXISTS `Notifications`;
CREATE TABLE IF NOT EXISTS `Notifications` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ApplicationId` int(11) NOT NULL,
  `Localization` varchar(10) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `ShortMessage` varchar(200) NOT NULL,
  `Message` text,
  `StatusId` int(11) DEFAULT NULL,
  `DeviceType` varchar(10) DEFAULT NULL,
  `StartDateValidation` datetime NOT NULL,
  `EndDateValidation` datetime NOT NULL,
  `LinkType` varchar(20) NOT NULL,
  `Link` text NOT NULL,
  `IconId` int(11) DEFAULT NULL,
  `CreationDate` datetime NOT NULL,
  `UpdateDate` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_StatusId` (`StatusId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `NotificationStatus`
--

DROP TABLE IF EXISTS `NotificationStatus`;
CREATE TABLE IF NOT EXISTS `NotificationStatus` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Name_UNIQUE` (`Name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `Providers`
--

DROP TABLE IF EXISTS `Providers`;
CREATE TABLE IF NOT EXISTS `Providers` (
  `Id` int(11) NOT NULL,
  `Name` varchar(450) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
CREATE TABLE IF NOT EXISTS `Users` (
  `Id` int(11) NOT NULL,
  `Name` varchar(1024) DEFAULT NULL,
  `Surname` varchar(1024) DEFAULT NULL,
  `Email` varchar(1024) DEFAULT NULL,
  `Phone` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ApplicationInternalLinks`
--
ALTER TABLE `ApplicationInternalLinks`
  ADD CONSTRAINT `fk_ApplicationId` FOREIGN KEY (`ApplicationId`) REFERENCES `Applications` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Devices`
--
ALTER TABLE `Devices`
  ADD CONSTRAINT `fk_DeviceTypeId` FOREIGN KEY (`TypeId`) REFERENCES `DeviceTypes` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_LocalizationId` FOREIGN KEY (`LocalizationId`) REFERENCES `Localizations` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Devices_Applications`
--
ALTER TABLE `Devices_Applications`
  ADD CONSTRAINT `fk_Devices_Application_ApplicationId` FOREIGN KEY (`ApplicationId`) REFERENCES `Applications` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Devices_Application_DeviceId` FOREIGN KEY (`DeviceId`) REFERENCES `Devices` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Devices_Notifications`
--
ALTER TABLE `Devices_Notifications`
  ADD CONSTRAINT `fk_Devices_Notifications_DeviceId` FOREIGN KEY (`DeviceId`) REFERENCES `Devices` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Devices_Notifications_NotificationId` FOREIGN KEY (`NotificationId`) REFERENCES `Notifications` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Devices_Users`
--
ALTER TABLE `Devices_Users`
  ADD CONSTRAINT `fk_Devices_Users_DeviceId` FOREIGN KEY (`DeviceId`) REFERENCES `Devices` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Devices_Users_UserId` FOREIGN KEY (`UserId`) REFERENCES `Users` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Notifications`
--
ALTER TABLE `Notifications`
  ADD CONSTRAINT `fk_StatusId` FOREIGN KEY (`StatusId`) REFERENCES `NotificationStatus` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
