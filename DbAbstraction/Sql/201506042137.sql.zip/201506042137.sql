-- MySQL dump 10.13  Distrib 5.5.43, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: NotificationManager
-- ------------------------------------------------------
-- Server version	5.5.43-0ubuntu0.14.04.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `AppLinks`
--

LOCK TABLES `AppLinks` WRITE;
/*!40000 ALTER TABLE `AppLinks` DISABLE KEYS */;
REPLACE INTO `AppLinks` (`Id`, `Name`, `AppId`) VALUES (5,'aaa',6),(6,'vvv',6),(7,'bbb',6);
/*!40000 ALTER TABLE `AppLinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Apps`
--

LOCK TABLES `Apps` WRITE;
/*!40000 ALTER TABLE `Apps` DISABLE KEYS */;
REPLACE INTO `Apps` (`Id`, `Name`, `GoogleKey`, `WindowsPhoneKey`, `ClientId`) VALUES (6,'Test1','','','034a78359a771197fe79432618e59ff0f88c76ca');
/*!40000 ALTER TABLE `Apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Configurations`
--

LOCK TABLES `Configurations` WRITE;
/*!40000 ALTER TABLE `Configurations` DISABLE KEYS */;
REPLACE INTO `Configurations` (`Key`, `Value`) VALUES ('GOOGLE_CLIENT_ID','539606674190-mplrvptcl1cbrkgooidd77tnsedojd7o.apps.googleusercontent.com'),('GOOGLE_CLIENT_SECRET','hxB_MzQasd4or4t-dbwrbIZz'),('GOOGLE_REDIRECT_URL','http://127.0.0.1:8873/Web/GoogleAccess.php'),('MINIFY_HTML','true'),('SHOW_PHP_ERRORS','true');
/*!40000 ALTER TABLE `Configurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `DeviceTypes`
--

LOCK TABLES `DeviceTypes` WRITE;
/*!40000 ALTER TABLE `DeviceTypes` DISABLE KEYS */;
REPLACE INTO `DeviceTypes` (`Id`, `Name`) VALUES ('ANDROID','ANDROID'),('IOS','IOS'),('WEB','WEB'),('WINDOWS_PHONE','WINDOWS_PHONE');
/*!40000 ALTER TABLE `DeviceTypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Devices`
--

LOCK TABLES `Devices` WRITE;
/*!40000 ALTER TABLE `Devices` DISABLE KEYS */;
REPLACE INTO `Devices` (`Id`, `MobileId`, `Type`, `ApplicationVersion`, `Brand`, `Model`, `OSVersion`, `Enabled`) VALUES (2,'345345retgdsr','android','1.0',NULL,NULL,NULL,1),(68,'fsdfsdfsdfsd','android',NULL,NULL,NULL,NULL,0),(69,'3g34g34g34','android',NULL,NULL,NULL,NULL,0),(70,'sdfsdfsdfsdf','android',NULL,NULL,NULL,NULL,0),(71,'g34g34g34g43g','ios',NULL,NULL,NULL,NULL,0),(72,'34g43g34g43g','web',NULL,NULL,NULL,NULL,1),(73,'sdfsdfsdfsdrthrtyh6754fsdfsd','web',NULL,NULL,NULL,NULL,0),(74,'sdfsdfsdghjyghfkuyofsdfsdfsd','ios',NULL,NULL,NULL,NULL,0),(75,'234264555gv645bv3423','android',NULL,NULL,NULL,NULL,1),(76,'324234234','ios',NULL,NULL,NULL,NULL,0),(77,'2342342342','ios',NULL,NULL,NULL,NULL,1),(78,'hfddfh45vb6354 56','ios',NULL,NULL,NULL,NULL,1),(79,'2342423432','ios',NULL,NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `Devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Devices_Apps`
--

LOCK TABLES `Devices_Apps` WRITE;
/*!40000 ALTER TABLE `Devices_Apps` DISABLE KEYS */;
REPLACE INTO `Devices_Apps` (`DeviceId`, `AppId`, `CreationDate`, `UpdateDate`) VALUES (2,6,'',''),(68,6,'',''),(69,6,'',''),(70,6,'',''),(71,6,'',''),(72,6,'',''),(73,6,'',''),(74,6,'',''),(75,6,'',''),(76,6,'',''),(77,6,'',''),(78,6,'',''),(79,6,'','');
/*!40000 ALTER TABLE `Devices_Apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Devices_Notifications`
--

LOCK TABLES `Devices_Notifications` WRITE;
/*!40000 ALTER TABLE `Devices_Notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `Devices_Notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Devices_Users`
--

LOCK TABLES `Devices_Users` WRITE;
/*!40000 ALTER TABLE `Devices_Users` DISABLE KEYS */;
/*!40000 ALTER TABLE `Devices_Users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Icons`
--

LOCK TABLES `Icons` WRITE;
/*!40000 ALTER TABLE `Icons` DISABLE KEYS */;
/*!40000 ALTER TABLE `Icons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Notifications`
--

LOCK TABLES `Notifications` WRITE;
/*!40000 ALTER TABLE `Notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `Notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Providers`
--

LOCK TABLES `Providers` WRITE;
/*!40000 ALTER TABLE `Providers` DISABLE KEYS */;
/*!40000 ALTER TABLE `Providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'NotificationManager'
--

--
-- Dumping routines for database 'NotificationManager'
--
/*!50003 DROP FUNCTION IF EXISTS `getConfigurationValue` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `getConfigurationValue`(`@Key` VARCHAR(100)) RETURNS varchar(500) CHARSET latin1
    DETERMINISTIC
BEGIN

DECLARE `@Value` VARCHAR(500);

SELECT `Value` INTO `@Value`
FROM Configurations
WHERE `Key` = `@Key`; 

RETURN `@Value`;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `appDelete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `appDelete`(IN `@id` INT)
BEGIN

DELETE FROM Apps WHERE Id=`@id`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `appGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `appGet`(
	IN `@id` INT
	, IN `@name` VARCHAR(150)
    , IN `@perPage` INT
    , IN `@page` INT
)
BEGIN

SET @position := 0;

SELECT Id, `Name`, GoogleKey, WindowsPhoneKey, ClientId
FROM
(
	SELECT (@position := @position + 1) AS Position, Id, `Name`, GoogleKey, WindowsPhoneKey, ClientId
	FROM Apps
	WHERE (`@id` IS NULL OR `@id`=id)
		AND ( `@name` IS NULL OR `name` LIKE CONCAT('%',`@name`,'%') )
) AS PositionResult
WHERE Position>`@page`*`@perPage` AND Position<`@page`*`@perPage`+`@perPage`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `appGetCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `appGetCount`(
	IN `@id` INT
	, IN `@name` VARCHAR(150)
)
BEGIN

SELECT COUNT(Id) AS `AppCount`
FROM Apps
WHERE (`@id` IS NULL OR `@id`=id)
	AND ( `@name` IS NULL OR `name` LIKE CONCAT('%',`@name`,'%') );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `appInsert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `appInsert`(
	IN `@name` VARCHAR(150)
    , IN `@googleKey` VARCHAR(1024)
    , IN `@windowsPhoneKey` VARCHAR(1024)
	, IN `@clientId` VARCHAR(1024)
)
BEGIN

	INSERT INTO Apps(`Name`, GoogleKey, WindowsPhoneKey, ClientId)
	VALUES (`@name`, `@googleKey`, `@windowsPhoneKey`, `@clientId`);
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `applicationInsert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `applicationInsert`(
	IN `@name` VARCHAR(150)
    , IN `@googleKey` VARCHAR(1024)
    , IN `@windowsPhoneKey` VARCHAR(1024)
)
BEGIN

	INSERT INTO Apps(`name`, googleKey, windowsPhoneKey)
	VALUES (`@name`, `@googleKey`, `@windowsPhoneKey`);
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `appLinkDelete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `appLinkDelete`(
    `@AppId` INT
)
BEGIN

DELETE FROM AppLinks
WHERE AppId=`@AppId`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `appLinkGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `appLinkGet`(`@Name` VARCHAR(100), `@ApplicationId` INT)
BEGIN

SELECT Id, `Name`, AppId AS ApplicationId
FROM AppLinks
WHERE (`@Name` IS NULL OR `@Name`=`Name`)
	AND (AppId=`@ApplicationId` OR `@ApplicationId` IS NULL);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `appLinkInsert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `appLinkInsert`(
	`@Name` VARCHAR(100)
    , `@AppId` INT
)
BEGIN

INSERT INTO AppLinks(`Name`, AppId)
VALUES(`@Name`, `@AppId`);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `appUpdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `appUpdate`(
	IN `@id` INT
	, IN `@name` VARCHAR(150)
    , IN `@googleKey` VARCHAR(1024)
    , IN `@windowsPhoneKey` VARCHAR(1024)
)
BEGIN

	UPDATE Apps
	SET `name`=`@name`, googleKey=`@googleKey`, windowsPhoneKey=`@windowsPhoneKey`
	WHERE id=`@id`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `deviceDelete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `deviceDelete`(IN `@id` INT)
BEGIN

DELETE FROM Devices_Users WHERE DeviceId=`@id`;
DELETE FROM Devices_Notifications WHERE DeviceId=`@id`;
DELETE FROM Devices_Apps WHERE DeviceId=`@id`;
DELETE FROM Devices WHERE Id=`@id`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `deviceGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `deviceGet`(
	`@id` INT
	, `@enabled` INT
	, `@applicationId` INT
	, `@perPage` INT
	, `@page` INT
)
BEGIN

SET @position := 0;

SELECT Id
	, MobileId
	, `Type`
	, ApplicationVersion
	, ApplicationId
	, ApplicationName
	, Brand
	, Model
	, OSVersion
	, Enabled
FROM
(
	SELECT 
		(@position := @position + 1) AS Position
		, Devices.Id
		, MobileId
		, `Type`
		, ApplicationVersion
		, Apps.Id AS ApplicationId
		, Apps.`Name` AS ApplicationName
		, Brand
		, Model
		, OSVersion
		, Enabled
	FROM Devices
		INNER JOIN Devices_Apps ON Devices.Id=DeviceId
		INNER JOIN Apps ON Apps.Id=Devices_Apps.AppId
	WHERE (`@id` IS NULL OR `@id`=Devices.id)
		AND ( `@enabled` IS NULL OR `enabled` = `@enabled` )
		AND ( `@applicationId` IS NULL OR Apps.Id = `@applicationId` )
) AS PositionResult
WHERE Position>`@page`*`@perPage` AND Position<`@page`*`@perPage`+`@perPage`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `deviceGetCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `deviceGetCount`(
	`@id` INT
	, `@enabled` INT
	, `@applicationId` INT
)
BEGIN

SELECT 
	COUNT( Devices.Id ) AS `DeviceCount`
FROM Devices
	INNER JOIN Devices_Apps ON Devices.Id=DeviceId
	INNER JOIN Apps ON Apps.Id=Devices_Apps.AppId
WHERE (`@id` IS NULL OR `@id`=Devices.id)
	AND ( `@enabled` IS NULL OR `enabled` = `@enabled` )
	AND ( `@applicationId` IS NULL OR Apps.Id = `@applicationId` );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `deviceGetPageCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `deviceGetPageCount`(
	`@id` INT
	, `@enabled` INT
	, `@applicationId` INT
	, `@perPage` INT
)
BEGIN

SELECT 
	CEILING(COUNT(Devices.Id)/`@perPage`) AS PageCount
FROM Devices
	INNER JOIN Devices_Apps ON Devices.Id=DeviceId
	INNER JOIN Apps ON Apps.Id=Devices_Apps.AppId
WHERE (`@id` IS NULL OR `@id`=Devices.id)
	AND ( `@enabled` IS NULL OR `enabled` = `@enabled` )
	AND ( `@applicationId` IS NULL OR Apps.Id = `@applicationId` );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `deviceTypeGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `deviceTypeGet`()
BEGIN

SELECT `Name`
FROM DeviceTypes
ORDER BY Id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `deviceUpdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `deviceUpdate`(
	IN `@id` INT
	, IN `@enabled` INT
)
BEGIN

	UPDATE Devices
	SET `enabled`=`@enabled`
	WHERE id=`@id`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `notificationGet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `notificationGet`(
	`@id` INT
	, `@enabled` INT
	, `@applicationId` INT
	, `@perPage` INT
	, `@page` INT
)
BEGIN

SET @position := 0;

SELECT 
	Id
	, Title
	, Message
	, CreationDate
	, UpdateDate
	, `Status`
	, ApplicationId
	, ApplicationName
	, IconId
FROM
(
	SELECT 
		(@position := @position + 1) AS Position
		, Notification.Id
		, Title
		, Message
		, CreationDate
		, UpdateDate
		, `Status`
		, Applications.Id AS ApplicationId
		, Applications.Name AS ApplicationName
		, IconId
	FROM Notifications
		INNER JOIN Applications ON Applications.Id=Notifications.ApplicationId
	WHERE ( `@id` IS NULL OR Notifications.Id=`@id` )
		AND ( `@applicationId` IS NULL OR Applications.Id=`@applicationId` )
		AND  ( `@status` IS NULL OR Notifications.`Status`=`@status` )
) AS PositionResult
WHERE Position>`@page`*`@perPage` AND Position<`@page`*`@perPage`+`@perPage`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `notificationGetCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `notificationGetCount`(
	`@id` INT
	, `@applicationId` INT
	, `@status` INT
)
BEGIN

SELECT 
	COUNT(Devices.Id) AS NotificationCount
FROM Notifications
	INNER JOIN Apps ON Apps.Id=Notifications.ApplicationId
WHERE ( `@id` IS NULL OR Notifications.Id=`@id` )
	AND ( `@applicationId` IS NULL OR Apps.Id=`@applicationId` )
	AND  ( `@status` IS NULL OR Notifications.`Status`=`@status` );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `notificationGetPageCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `notificationGetPageCount`(
	`@id` INT
	, `@applicationId` INT
	, `@status` INT
	, `@perPage` INT
)
BEGIN

SELECT 
	CEILING(COUNT(Notifications.Id)/`@perPage`) AS PageCount
FROM Notifications
	INNER JOIN Apps ON Apps.Id=Notifications.ApplicationId
WHERE ( `@id` IS NULL OR Notifications.Id=`@id` )
	AND ( `@applicationId` IS NULL OR Apps.Id=`@applicationId` )
	AND  ( `@status` IS NULL OR Notifications.`Status`=`@status` );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `notificationInsert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `notificationInsert`(
	`@Title` VARCHAR(100)
	, `@Message` TEXT
	, `@Status` VARCHAR(20)
	, `@DeviceType` VARCHAR(45)
	, `@StartDate` VARCHAR(14)
	, `@EndDate` VARCHAR(14)
)
BEGIN

INSERT INTO Notifications(`Title`, `Message`, `Status`, `DeviceType`, `StartDate`, `EndDate`)
VALUES (`@Title`, `@Message`, `@Status`, `@DeviceType`, `@StartDate`, `@EndDate`);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-06-04 21:37:58
